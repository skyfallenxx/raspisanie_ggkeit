## Запуск на Windows

1. Распакуйте архив в отдельную папку. Создайте бота командой `/newbot` у [@BotFather](https://t.me/BotFather) и скопируйте выданный токен. [Инструкция Telegram](https://core.telegram.org/bots/tutorial).
2. Если на компьютере нет Node.js 22 или новее, установите его с [сайта Node.js](https://nodejs.org/en/download). Для ввода текстом этого достаточно.
3. Для фотографий установите Tesseract OCR с языками **Russian (rus)** и **English (eng)**. Для чтения белорусских названий добавьте **Belarusian (bel)** и задайте переменную среды `OCR_LANG=rus+bel+eng`. Бот ищет Tesseract в стандартной папке Windows и в `PATH`. Если выбрали другую папку, укажите полный путь к `tesseract.exe` в переменной среды `TESSERACT_PATH`. [Установка Tesseract](https://tesseract-ocr.github.io/tessdoc/Installation.html).
4. Откройте `start.cmd` и вставьте токен в окно запуска. Ввод скрыт, токен остаётся в памяти текущего процесса. Откройте ссылку на бота из окна запуска и нажмите **Start**. Бот отвечает, пока окно запуска открыто и компьютер подключён к интернету.


Для автоматического обновления расписания с сайта установите Python и выполните в терминале: 

    python -m pip install pdfplumber

