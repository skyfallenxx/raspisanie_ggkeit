## Запуск на Android

1. Установите [Termux](https://f-droid.org/packages/com.termux/) и скачайте telegram-schedule-android.zip в папку «Загрузки».
2. В Termux выполните первую команду и разрешите доступ к файлам.

    ~~~bash
    termux-setup-storage
    ~~~

3. Скопируйте команды в Termux.

    ~~~bash
    pkg install -y unzip
    unzip -o ~/storage/downloads/telegram-schedule-android.zip -d ~
    cd ~/telegram-schedule
    bash start-android.sh
    ~~~

4. Скрипт установит зависимости и попросит токен от [@BotFather](https://t.me/BotFather). После запуска откройте своего бота в Telegram и нажмите Start.

Для повторного запуска выполните в Termux:

~~~bash
cd ~/telegram-schedule && bash start-android.sh
~~~

Для работы в фоне разрешите Termux работу без ограничений в настройках батареи Android. После перезагрузки телефона запустите бота снова.
