#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
umask 077

if ! command -v pkg >/dev/null || ! command -v termux-wake-lock >/dev/null; then
  printf '%s\n' 'Открой Termux и запусти этот скрипт командой bash start-android.sh.' >&2
  exit 1
fi

cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

packages=()
command -v node >/dev/null || packages+=(nodejs-lts)
command -v tesseract >/dev/null || packages+=(tesseract)
command -v curl >/dev/null || packages+=(curl)
command -v magick >/dev/null || packages+=(imagemagick)
command -v python3 >/dev/null || packages+=(python)
if (( ${#packages[@]} )); then
  printf '%s\n' 'Устанавливаю пакеты для бота. Это нужно только при первом запуске.'
  pkg install -y "${packages[@]}"
fi

if ! python3 -m pip --version >/dev/null 2>&1; then
  pkg install -y python-pip
fi
if ! python3 -c 'import cryptography' >/dev/null 2>&1; then
  pkg install -y python-cryptography
fi
export SCHEDULE_PYTHON="$(command -v python3)"
export PYTHONPATH="$PWD/.pdf-packages${PYTHONPATH:+:$PYTHONPATH}"
if ! python3 -c 'import pdfplumber; assert pdfplumber.__version__ == "0.11.9"' >/dev/null 2>&1; then
  printf '%s\n' 'Устанавливаю чтение PDF с сайта колледжа.'
  # Используем текстовый слой PDF. Библиотеки отрисовки страниц здесь не нужны.
  python3 -m pip install --disable-pip-version-check --no-deps --only-binary=:all: --upgrade \
    --target "$PWD/.pdf-packages" 'pdfplumber==0.11.9' 'pdfminer.six==20251230' 'charset-normalizer==3.4.4'
  python3 -c 'import pdfplumber'
fi

if ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)'; then
  printf '%s\n' 'Обнови Node.js в Termux до версии 22 или новее.' >&2
  exit 1
fi

export TESSDATA_PREFIX="$PWD/.tessdata"
export OCR_LANG="${OCR_LANG:-rus+eng}"
export OMP_THREAD_LIMIT="${OMP_THREAD_LIMIT:-2}"
mkdir -p -- "$TESSDATA_PREFIX"
IFS=+ read -r -a languages <<< "$OCR_LANG"
for language in "${languages[@]}"; do
  if [[ ! "$language" =~ ^[a-z][a-z0-9_]*$ ]]; then
    printf '%s\n' 'Проверь коды языков в OCR_LANG.' >&2
    exit 1
  fi
  model="$TESSDATA_PREFIX/$language.traineddata"
  if [[ ! -s "$model" ]]; then
    printf 'Загружаю модель распознавания %s.\n' "$language"
    curl --fail --silent --show-error --location --retry 3 --connect-timeout 15 --max-time 90 \
      --output "$model.part" "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$language.traineddata"
    mv -- "$model.part" "$model"
  fi
done

token_file="$PWD/.termux-bot-token"
if [[ "${1:-}" == '--new-token' || -z "${TELEGRAM_BOT_TOKEN:-}" ]]; then
  if [[ "${1:-}" != '--new-token' && -s "$token_file" ]]; then
    TELEGRAM_BOT_TOKEN="$(<"$token_file")"
  else
    read -r -s -p 'Вставь токен от @BotFather и нажми Enter: ' TELEGRAM_BOT_TOKEN
    printf '\n'
    if [[ ! "$TELEGRAM_BOT_TOKEN" =~ ^[0-9]+:[A-Za-z0-9_-]+$ ]]; then
      printf '%s\n' 'Проверь токен от @BotFather.' >&2
      exit 1
    fi
    printf '%s\n' "$TELEGRAM_BOT_TOKEN" > "$token_file"
  fi
fi
export TELEGRAM_BOT_TOKEN

if termux-wake-lock; then
  trap 'termux-wake-unlock' EXIT
else
  printf '%s\n' 'Termux не смог включить работу при погашенном экране.' >&2
fi
node app/bot.mjs
