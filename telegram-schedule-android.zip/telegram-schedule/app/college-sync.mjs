import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, rm, rmdir, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { normalizeGroup } from './schedule.mjs';

const run = promisify(execFile);
const origin = 'https://electrocollege.by';
const student = '/v-pomoshh-uchashhemusya/';
const sources = {
  pto: student + 'uchashhemusya-urovnya-pto/',
  sso: student + 'uchashhemusya-poluchayushhemu-srednee-spetsialnoe-obrazovanie/',
};
export const currentCollegeSchedules = readFile(new URL('./college-weekly.json', import.meta.url), 'utf8').then(JSON.parse);

function collegeUrl(href, base) {
  try {
    const url = new URL(href.replaceAll('&amp;', '&'), base);
    if (url.origin === origin && !url.username && !url.password) return url;
  } catch {
    // An invalid link should not block other links on the page.
  }
  return null;
}

function links(html, base) {
  return [...html.matchAll(/<a\b[^>]*\bhref\s*=\s*(['"])(.*?)\1[^>]*>([\s\S]*?)<\/a>/giu)]
    .flatMap(([, , href, label]) => {
      const url = collegeUrl(href, base);
      const title = label.replace(/<[^>]*>/gu, ' ').replace(/&(?:nbsp|ndash|mdash);/giu, ' ').replace(/\s+/gu, ' ').trim();
      return url ? [{ url, title }] : [];
    });
}

async function download(url, request, maxBytes) {
  const response = await request(url, { signal: AbortSignal.timeout(20_000), redirect: 'error' });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  if (!response.body || Number(response.headers.get('content-length')) > maxBytes) throw new Error('Неподходящий размер файла');
  const parts = [];
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.length;
    if (size > maxBytes) throw new Error('Файл слишком большой');
    parts.push(chunk);
  }
  return Buffer.concat(parts);
}

export async function readCollegePdf(pdf) {
  const directory = await mkdtemp(join(tmpdir(), 'college-weekly-'));
  try {
    const input = join(directory, 'schedule.pdf');
    const output = join(directory, 'schedule.json');
    await writeFile(input, pdf);
    const localPython = await readFile(new URL('../data/college-python.path', import.meta.url), 'utf8').catch(error => {
      if (error.code === 'ENOENT') return '';
      throw error;
    });
    const python = process.env.SCHEDULE_PYTHON || localPython.trim() || (process.platform === 'win32' ? 'python' : 'python3');
    const script = fileURLToPath(new URL('./read-college-pdf.py', import.meta.url));
    await run(python, ['-X', 'utf8', script, input, output], { timeout: 45_000, windowsHide: true });
    return JSON.parse(await readFile(output, 'utf8'));
  } finally {
    await Promise.all([
      rm(join(directory, 'schedule.pdf'), { force: true }),
      rm(join(directory, 'schedule.json'), { force: true }),
    ]);
    await rmdir(directory);
  }
}

function validate(groups) {
  const profiles = Object.entries(groups);
  if (profiles.length < 2 || profiles.some(([group, subgroups]) => normalizeGroup(group) !== group ||
    [1, 2].some(n => ![0, 1, 2, 3, 4].every(day => Object.keys(subgroups[n]?.[day] || {}).length)))) {
    throw new Error('Не удалось прочитать полное расписание');
  }
}

export async function syncCollegeSchedules(store, { request = fetch, parse = readCollegePdf, log = console.warn } = {}) {
  const bundled = await currentCollegeSchedules;
  await Promise.all(Object.entries(sources).map(async ([level, path]) => {
    try {
      const section = new URL(path, origin);
      const index = (await download(section, request, 2_000_000)).toString('utf8');
      const publication = links(index, section).find(({ title }) =>
        /^расписание\s+занятий(?:\s|$)/iu.test(title));
      if (!publication) throw new Error('Не найдена публикация основного расписания');
      const post = (await download(publication.url, request, 2_000_000)).toString('utf8');
      const files = links(post, publication.url).filter(({ url }) => /\.pdf$/iu.test(url.pathname));
      const file = files.find(({ url, title }) => /raspisanie|расписан/iu.test(url.pathname + ' ' + title));
      if (!file) throw new Error('Не найдена ссылка на PDF расписания');
      const pdf = await download(file.url, request, 12_000_000);
      if (pdf.subarray(0, 5).toString('ascii') !== '%PDF-') throw new Error('Ссылка не вернула PDF');
      const digest = createHash('sha256').update(pdf).digest('hex');
      const key = 'college-' + level;
      const saved = await store.read(key);
      if (saved.digest === digest || (!saved.digest && bundled[level]?.digest === digest)) return;
      const groups = bundled[level]?.digest === digest ? bundled[level].groups : await parse(pdf);
      validate(groups);
      await store.save(key, { digest, groups });
    } catch (error) {
      const detail = error.code === 'ENOENT' ? 'не найден Python для чтения нового PDF' :
        /No module named 'pdfplumber'/u.test(error.stderr || '') ? 'не установлен pdfplumber' :
        error.stderr ? 'не удалось разобрать новый PDF' : error.message;
      log(`Основное расписание ${level.toUpperCase()}: ${detail}`);
    }
  }));
}
