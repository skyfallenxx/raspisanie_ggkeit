import { dayIndex, InputError, lessonEntries, normalizeGroup, parseBase } from './schedule.mjs';

export function parseWeeklySheetText(text) {
  const lines = text.trim().split(/\r?\n/u);
  if (!/^группа\s+/iu.test(lines[0]?.trim() || '')) return null;
  const groups = {};
  let group;
  let subgroup;
  let block = [];
  function finish() {
    if (!group) return;
    if (!block.length) throw new InputError(`Добавьте уроки для группы ${group}.`);
    const week = parseBase(block.join('\n'));
    const profiles = groups[group] ??= {};
    for (const number of subgroup ? [subgroup] : [1, 2]) {
      if (profiles[number]) throw new InputError(`Расписание группы ${group}, подгруппа ${number}, указано дважды.`);
      profiles[number] = week;
    }
    block = [];
  }
  for (const original of lines) {
    const line = original.trim();
    if (!line) continue;
    const header = /^группа\s+([\p{L}\d –—-]+?)(?:\s*[·,]\s*подгруппа\s*([12]))?$/iu.exec(line);
    if (header) {
      finish();
      group = normalizeGroup(header[1]);
      subgroup = header[2];
      if (!group) throw new InputError('Проверьте название группы в строке «' + line + '».');
    } else block.push(line);
  }
  finish();
  return groups;
}

function cellLessons(words, sharedNumber) {
  const line = words.map(word => word.text).join(' ').trim();
  const numbered = lessonEntries(line);
  return numbered.length ? numbered : sharedNumber && /\p{L}/u.test(line) ? [[sharedNumber, line]] : [];
}

function subgroupMarkers(text) {
  return text
    .replace(/(?:^|\s)([12])\s*(?:nr|nг|пr|иг|шг)\.?\s+(?=\p{L})/giu, ' $1пг ')
    .replace(/(?:^|\s)(?:I|l)(?:nr|or|пг)\.?\s+(?=\p{L})/giu, ' 1пг ')
    .trim();
}

export function weeklyGroupsFromRows(rows, geometry = {}) {
  const { rules = [], groupEdges = [], bodyEdges = [] } = geometry;
  const headerIndex = rows.findIndex(row => row.words.filter(word => normalizeGroup(word.text)).length >= 2);
  if (headerIndex < 0) return null;
  const headers = rows[headerIndex].words.flatMap(word => {
    const group = normalizeGroup(word.text);
    return group ? [{ group, x: word.x }] : [];
  });
  if (new Set(headers.map(header => header.group)).size !== headers.length) return null;
  const bounds = headers.map(({ x }) => {
    const left = groupEdges.findLast(edge => edge < x);
    const right = groupEdges.find(edge => edge > x);
    const inside = bodyEdges.filter(edge => edge > left + 3 && edge < right - 3);
    return left !== undefined && right !== undefined ? { left, right, inside } : null;
  });
  const useBounds = bounds.every(Boolean) && new Set(bounds.map(bound => bound.left)).size === headers.length;
  const firstLeft = useBounds ? bounds[0].left : headers[0].x - (headers[1].x - headers[0].x) / 2;
  const dayRows = rows.slice(headerIndex + 1);
  const hasDayNames = dayRows.some(row => row.words.some(word => word.x < firstLeft && dayIndex(word.text) >= 0));
  const bands = rules.filter(y => y > rows[headerIndex].y);
  const inferredDays = !hasDayNames && bands.length === 6 && bands.slice(1).every((y, i) =>
    y - bands[i] >= rows[headerIndex].height * 4);
  const plans = headers.map(() => ({ 1: {}, 2: {} }));
  const previous = headers.map(() => null);
  const seenDays = new Set();
  let day = -1;
  for (const row of dayRows) {
    const margin = row.words.filter(word => word.x < firstLeft);
    const dayWord = margin.find(word => dayIndex(word.text) >= 0);
    const band = inferredDays ? bands.findIndex(y => y > row.y) - 1 : -1;
    if (dayWord || band >= 0) {
      const next = dayWord ? dayIndex(dayWord.text) : band;
      if (next < day) break;
      if (next !== day) previous.fill(null);
      day = next;
      seenDays.add(day);
    }
    if (inferredDays && band < 0) continue;
    if (day < 0) continue;
    const sharedNumber = margin.find(word => /^\d{1,2}[.)]?$/u.test(word.text));
    const cells = headers.map(() => []);
    for (const word of row.words) {
      if (word.x < firstLeft) continue;
      if (useBounds) {
        const column = bounds.findIndex(bound => word.x >= bound.left && word.x < bound.right);
        if (column >= 0) cells[column].push(word);
        continue;
      }
      let column = 0;
      while (column + 1 < headers.length && word.x >= (headers[column].x + headers[column + 1].x) / 2) column++;
      cells[column].push(word);
    }
    for (const [i, words] of cells.entries()) {
      const [subjectX, roomX] = useBounds && bounds[i].inside.length === 2 ? bounds[i].inside : [];
      let cell = words.map(word => word.text).join(' ');
      let room = '';
      let numberText = '';
      if (subjectX) {
        const text = words.filter(word => word.x >= subjectX && word.x < roomX).map(word => word.text).join(' ');
        numberText = words.filter(word => word.x < subjectX).map(word => word.text).join('');
        room = words.filter(word => word.x >= roomX).map(word => word.text).join('');
        room = /^м?\d{1,3}[\p{L}]?$/iu.test(room) ? 'каб. ' + room : /^с\/?з$/iu.test(room) ? 'спортзал' : '';
        cell = text;
      }
      cell = subgroupMarkers(cell);
      const continuation = /^([12])\s*(?:п\.?\s*\/?\s*г\.?|подгруппа)\s*[:.)-]?\s+(.+)$/iu.exec(cell);
      const lessons = !numberText && continuation && previous[i] ? previous[i].slots.map(slot => [slot, cell]) :
        cellLessons([{ text: subjectX ? [numberText, cell].filter(Boolean).join('. ') : cell }],
          subjectX ? null : sharedNumber && parseInt(sharedNumber.text, 10)).filter(([slot]) => slot >= 1 && slot <= 20 &&
          (!subjectX || /^\d{1,2}(?:[,–—-]\d{1,2})?$/u.test(numberText)));
      if (!lessons.length && subjectX && !numberText && room && previous[i]) {
        for (const n of previous[i].subgroups) for (const slot of previous[i].slots) {
          const slots = plans[i][n][day];
          if (slots?.[slot] && !/каб\.|спортзал|обед|урока нет/iu.test(slots[slot])) slots[slot] += ' — ' + room;
        }
      }
      if (!lessons.length) continue;
      const active = new Set();
      for (const [slot, subject] of lessons) {
        const values = {};
        const parts = [...subject.matchAll(/([12])\s*(?:п\.?\s*\/?\s*г\.?|подгруппа)\s*[:.)-]?\s+(.+?)(?=\s*\/?\s*[12]\s*(?:п\.?\s*\/?\s*г\.?|подгруппа)(?=[\s:.)-])|$)/giu)];
        if (parts.length) {
          for (const [, number, lesson] of parts) values[number] = lesson.trim();
        } else if (/\p{L}/u.test(subject)) {
          values[1] = values[2] = subject;
        }
        for (const [number, lesson] of Object.entries(values)) {
          active.add(number);
          const slots = plans[i][number][day] ??= {};
          if (parts.length || !slots[slot]) {
            const subjectOnly = lesson.replace(/\s+[\p{Lu}-]+\s*\p{Lu}\.\s*\p{Lu}\.?$/u, '').trim();
            slots[slot] = [subjectOnly || slots[slot], room].filter(Boolean).join(' — ');
          }
        }
      }
      previous[i] = { slots: lessons.map(([slot]) => slot), subgroups: [...active] };
    }
  }
  const groups = {};
  // A single weekday from a low-resolution sheet is too little to publish a weekly plan.
  if (seenDays.size < 2) return { groups, headers: headers.map(h => h.group) };
  for (const [i, { group }] of headers.entries()) {
    const usable = Object.fromEntries(Object.entries(plans[i]).filter(([, week]) => Object.keys(week).length === seenDays.size));
    if (Object.keys(usable).length) groups[group] = usable;
  }
  return { groups, headers: headers.map(h => h.group) };
}
