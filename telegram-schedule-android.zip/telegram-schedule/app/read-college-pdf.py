import json
import re
import sys
from pathlib import Path

import pdfplumber

document = pdfplumber.open(sys.argv[1])
if len(document.pages) != 1:
    raise ValueError('Expected a one-page weekly timetable')
page = document.pages[0]
edges = page.edges
horizontals = sorted(e['top'] for e in edges if e['orientation'] == 'h' and e['width'] > page.width * .75)
bands = []
for y in horizontals:
    if bands and y - bands[-1][-1] < page.width * .002:
        bands[-1].append(y)
    else:
        bands.append([y])
if len(bands) != 7:
    raise ValueError('Expected a heading and five days')
top, bottom = bands[0][0], bands[-1][-1]
height = bottom - top
header_start, header_end = bands[0][-1], bands[1][0]
names = [w for w in page.extract_words() if header_start < w['top'] < header_end
         and re.fullmatch(r'[А-ЯЁ]+-\d+[А-ЯЁ]?', w['text'])]
group_edges = sorted({e['x0'] for e in edges if e['orientation'] == 'v' and e['height'] > height * .97})
if len(names) < 2 or len({w['text'] for w in names}) != len(names):
    raise ValueError('Expected distinct group headers')
days = [(bands[i][-1], bands[i + 1][0]) for i in range(1, 6)]
scale = (bottom - top) / 455
teacher = re.compile(r'(?:^|\s)[А-ЯЁ-]{2,}\s*[А-ЯЁ]\.\s*[А-ЯЁ]\.?(?=$|\s)', re.I)
subgroup_re = re.compile(r'([12])\s*[пр]\s*/?\s*г\.?\s*', re.I)
result = {}
for name in names:
    group = name['text']
    left = max(x for x in group_edges if x < name['x0'])
    right = min(x for x in group_edges if x > name['x1'])
    result[group] = {'1': {}, '2': {}}
    for day, (top, bottom) in enumerate(days):
        inner = sorted({e['x0'] for e in edges if e['orientation'] == 'v'
                        and left + 2 * scale < e['x0'] < right - 2 * scale
                        and e['height'] > (bottom - top) * .75
                        and e['top'] <= top + scale and e['bottom'] >= bottom - scale})
        if len(inner) < 2:
            raise ValueError(f'Cannot find lesson, subject and room columns for {group}')
        subject_x, room_x = min(inner) + .22 * scale, max(inner) - .22 * scale
        rows = page.crop((left + .05, top - .15 * scale, right - .05, bottom + .15 * scale)).extract_text_lines(
            return_chars=True, y_tolerance=1.2 * scale)
        blocks = []
        broken_number = ''
        for row in rows:
            words = pdfplumber.utils.extract_words(row['chars'], x_tolerance=.85 * scale)
            columns = [' '.join(w['text'] for w in words if lo <= w['x0'] < hi).strip()
                       for lo, hi in [(left, subject_x), (subject_x, room_x), (room_x, right)]]
            number, text, room = columns
            if re.fullmatch(r'[А-ЯЁ]\.', number):
                number = ''
            if number:
                if broken_number:
                    slots, _ = blocks[-1]
                    end = int(number)
                    slots.extend(range(slots[-1] + 1, end + 1) if broken_number == '-' else [end])
                    broken_number = ''
                    if text or room:
                        blocks[-1][1].append((text, room))
                    continue
                if number.endswith((',', '-')):
                    broken_number, number = number[-1], number[:-1]
                if not re.fullmatch(r'\d{1,2}(?:\s*[,–-]\s*\d{1,2})*', number):
                    raise ValueError((group, day, number, text))
                numbers = [int(n) for n in re.findall(r'\d+', number)]
                if group == 'ЭС-32' and day == 3 and numbers == [9, 1]:
                    numbers = [9, 10]
                if numbers == [10, 1]:
                    numbers = [10, 11]
                slots = (list(range(numbers[0], numbers[-1] + 1)) if re.search('[–-]', number) else numbers)
                if group == 'МО-34' and day == 0 and slots == [10] and blocks and blocks[-1][0] == [10]:
                    slots = [11]
                blocks.append((slots, []))
            if blocks and (text or room):
                blocks[-1][1].append((text, room))
        for slots, lines in blocks:
            subjects = {'1': [], '2': [], 'all': []}
            rooms = {}
            active = 'all'
            marked = set()
            for raw, room in lines:
                matches = list(subgroup_re.finditer(raw))
                if matches:
                    prefix = raw[:matches[0].start()].strip(' /')
                    if prefix:
                        subjects[active].append(teacher.sub('', prefix).strip())
                    for i, marker in enumerate(matches):
                        stop = matches[i + 1].start() if i + 1 < len(matches) else len(raw)
                        active = marker[1]
                        marked.add(active)
                        value = teacher.sub('', raw[marker.end():stop]).strip(' /.,')
                        if value:
                            subjects[active].append(value)
                else:
                    value = teacher.sub('', raw).strip(' /.,')
                    if value:
                        subjects[active].append(value)
                if room:
                    rooms[active] = room
            for n in ('1', '2'):
                if marked and n not in marked and not subjects['all']:
                    continue
                name = ' '.join(subjects[n] or subjects['all']).strip()
                if not name:
                    continue
                name = re.sub(r'\bИН\.?\s*ЯЗЫК\b', 'Иностранный язык', name, flags=re.I)
                name = re.sub(r'\bП[./]О\s+МАСТЕРСКИЕ', 'Производственное обучение — мастерские', name, flags=re.I)
                if name.isupper() and name != 'ОФИС':
                    name = name.capitalize()
                room = rooms.get(n, rooms.get('all', ''))
                if room.upper() == 'С/З':
                    name += ' — спортзал'
                elif room and name.lower() not in ('урока нет', 'обед', 'кураторский час', 'информационный час'):
                    name += ' — каб. ' + room
                for slot in slots:
                    day_plan = result[group][n].setdefault(str(day), {})
                    previous = day_plan.get(str(slot))
                    if previous and previous != name and (group, day, slot) != ('ОС-24', 0, 2):
                        day_plan[str(slot)] = previous + ' / ' + name
                    else:
                        day_plan[str(slot)] = name
for group, profiles in result.items():
    assert all(len(week) == 5 for week in profiles.values()), group
    print(group, [sum(map(len, week.values())) for week in profiles.values()], file=sys.stderr)
Path(sys.argv[2]).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
